/* Does pretty much nothing. */

#include "tests/lib.h"

int main(int argc, char* argv[] UNUSED) {
  return argc;
}
